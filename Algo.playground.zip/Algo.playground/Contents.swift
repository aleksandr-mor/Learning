import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let nums = [30, 1, 4, 6, 25, 12]
nums.forEach { num in
    DispatchQueue.main.asyncAfter(deadline: .now() + Double(num)/10) {
        print(num)
    }
}

// Funny algo from Twitter :D
