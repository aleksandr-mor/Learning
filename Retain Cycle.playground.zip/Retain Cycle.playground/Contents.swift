import UIKit

class Person {
    let name: String
    init(name: String) {
        self.name = name
    }
    deinit {
        print("\(name) was deinitialized")
    }
}

class Appartment {
    let number: Int
    var tenant: Person?
    init(number: Int) {
        self.number = number
    }
}

class Aleks: Person {
}

var bob: Person? = Person(name: "Bob")

let apt = Appartment(number: 123)

apt.tenant = bob

bob = nil

apt.tenant = nil
var aleks: Aleks? = Aleks(name: "Aleks")
aleks = nil
