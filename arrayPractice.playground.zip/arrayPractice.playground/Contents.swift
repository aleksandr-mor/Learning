import UIKit

var someArray = [Int]()
var someInts:[Int] = [10, 20, 30]
var someInts = [Int](count: 3, repeatedValue: 0)
var someInts = [Int](repeating: 10, count: 3)
var someVar = someInts[0]

print(someVar)
print(someInts[1])
print(someInts[2])


var someInts = [Int]()

someInts.append(20)
someInts.append(30)
someInts += [40]

var someVar = someInts[0]

print(someVar)
print(someInts[1])
print(someInts[2])

var someStrings = [String]()

someStrings.append("Apple")
someStrings.append("Amazon")
someStrings += ["Google"]

for item in someStrings {
    print(item)
}

var someStr = [String]()

someStr.append("Apple")
someStr.append("Amazon")
someStr += ["Google"]

for (index, item) in someStr.enumerated() {
    print("\(index) is \(item)")
}

var intsA = [Int](repeating: 2, count: 2)
var intsB = [Int](repeating: 1, count: 3)
var intsC = intsA + intsB

for item in intsC {
    print(item)
}

var intsA = [Int](repeating: 2, count: 2)
var intsB = [Int](repeating: 1, count: 3)
var intsC = [Int]()

print(intsA.isEmpty)
print(intsB.isEmpty)
print(intsC.isEmpty)
