import UIKit

protocol Greet {
    var name: String { get }

    func message()
}

class Employee: Greet {

    var name = "Perry"

    func message() {
        print("Good Morning", name)
    }
}

var employee1 = Employee()
employee1.message()

//=================================

protocol Polygon {
    func getArea(length: Int, breadth: Int)
}

class Rectangle: Polygon {

    func getArea(length: Int, breadth: Int) {
        print("Area of the rectangle:", length * breadth)
    }
}

var r1 = Rectangle()

r1.getArea(length: 5, breadth: 6)

//=================================

protocol Sum {

    func addition()
}

protocol Multiplication {

    func product()
}

class Calculate: Sum, Multiplication {

    var num1 = 0
    var num2 = 0

    func addition() {
        let result1 = num1 + num2
        print("Sum", result1)
    }
    func product() {
        let result2 = num1 * num2
        print("Product:", result2)
    }
}

var calc1 = Calculate()

calc1.num1 = 5
calc1.num2 = 10

calc1.addition()
calc1.product()

//=================================

protocol Car {

    var colorOptions: Int { get }
}

protocol Brand: Car {

    var name: String { get }
}

class Mercedes: Brand {

    var name: String = ""
    var colorOptions: Int = 0
}

var car1 = Mercedes()
car1.name = "Mercedes AMG"
car1.colorOptions = 4

print("Name:", car1.name)
print("Color Options:", car1.colorOptions)

//=================================

protocol Brake {
    func applyBrake()
}

class Car: Brake {
    var speed: Int = 0
    
    func applyBrake() {
        print("Brake Applied")
    }
}

extension Brake {
    func stop() {
        print("Engine Stopped")
    }
}

let car1 = Car()
car1.speed = 61
print("Speed:", car1.speed)

car1.applyBrake()

car1.stop()
