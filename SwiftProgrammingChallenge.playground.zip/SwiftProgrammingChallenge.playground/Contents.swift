import UIKit

let array = [1, 2, 1, 2, 3, 2, 1, 4]

print(array)


// with order
func removeDuplicates(array : [Int]) -> [Int] {
    var tempArray = [Int]()
    for element in array {
        if !tempArray.contains(element) {
            tempArray.append(element)
        }
    }
   return tempArray
}


let arrayWithoutDuplicate = removeDuplicates(array: array)
print(arrayWithoutDuplicate)


// Array without duplicate but not in order
let sets = Set(array)
print(sets)
