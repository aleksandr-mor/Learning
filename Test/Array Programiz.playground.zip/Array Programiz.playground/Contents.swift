import UIKit

// an array of integer type
var numbers: [Int] = [2, 4, 6, 8]

print("Array: \(numbers)")

var numbers = [2, 4, 6, 8]
print("Array: \(numbers)")

var value = [Int]()
print(value)

var languages = ["Swift", "Java", "C++"]

// access element at index 0
print(languages[0])

//access element at index 2
print(languages[2])

var numbers = [21, 34, 54, 12]

print("Before Append: \(numbers)")

// useng append method

numbers.append(32)

print("After Append \(numbers)")



var primeNumbers = [2, 3, 5]
print("Array1: \(primeNumbers)")

var evenNumbers = [4, 6, 8]
print("Array2: \(evenNumbers)")

// join two arrays
primeNumbers.append(contentsOf: evenNumbers)
print("Array after append: \(primeNumbers)")

var numbers = [21, 34, 54, 12]
print("Before Insert: \(numbers)")

numbers.insert(32, at: 1)
print("After Insert: \(numbers)")

var dailyActivities = ["Eat", "Repeat"]
print("Initial Array: \(dailyActivities)")

// change element at index 1
dailyActivities[1] = "Sleep"
print("Updated Array: \(dailyActivities)")

var languages = ["Swift", "Java", "Python"]
print("Initial Array: \(languages)")

// remove element at index 1
let removedValue = languages.remove(at: 1)

print("Updated Array: \(languages)")
print("Removed Value: \(removedValue)")

// an array of fruits
let fruits = ["Apple", "Peach", "Mango"]

// for loop to iterate over array
for fruit in fruits {
    print(fruit)
}
