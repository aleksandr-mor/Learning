import UIKit
// Sorting
let numbers: [Int] = [0, 2, 1, 3, 6, 4, 9, 7, 8]
let ascendingNumbers = numbers.sorted()

//
//let ascendingNumbers  = numbers.sorted{$0 < $1}
print (numbers)
print (ascendingNumbers)



// Map
let number: [String] = ["1", "one", "2", "two"]
let mapped : [Int?] = number.map{Int($0)}
print(mapped)

// Compact map
let number2: [String] = ["1", "one", "2", "two"]
let cmapped: [Int] = number2.compactMap{Int($0)}
print(cmapped)

// Flat map
let flatMapped = [[1,2,3,4], [4,5,6]]
print(flatMapped.flatMap {$0})
let scoresByName = ["aleks": [0, 5, 8], "vishal": [2, 5, 8]]
let flatMapped2 = scoresByName.flatMap { $0.key }
print(flatMapped2)
