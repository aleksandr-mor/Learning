import UIKit

class Car {
    
    var model: String
    var engine: String
    
    init(model: String, engine: String) {
        self.model = model
        self.engine = engine
    }
    convenience init(model: String) {
        self.init(model: model, engine: "Electrical")
    }
}

let car = Car(model: "Mercedes", engine: "Diesel")
print("Car model is \(car.model) and engine is \(car.engine)")
// Car model is Mercedes and engine is Diesel

let car1 = Car(model: "Toyota")
print("Car1 model is \(car1.model) and engine is \(car1.engine)")
// Car1 model is Toyota and engine is Electrical

