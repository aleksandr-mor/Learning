import UIKit

//func useWorkItem() {
//    var value = 10
//
//    let workItem = DispatchWorkItem {
//        value += 5
//    }
//
//workItem.perform()
//
//    let queue = DispatchQueue.global(qos: .utility)
//
//    queue.async(execute: workItem)
//
//    workItem.notify(queue: DispatchQueue.main) {
//        print("value =", value)
//    }
//}
//useWorkItem()




let workItem = DispatchWorkItem {
    // Your async code in here
}

// Execute the work after 1 second
DispatchQueue.main.asyncAfter(deadline: .now() + 1,execute: workItem)

// You can cancel the work item if you no longer need it
workItem.cancel()

