import UIKit

var someDict = [Int: String]()

var someDict:[Int: String] = [1: "One", 2: "Two", 3: "Three"]

var cities = ["Moscow", "Mountain View", "Norilsk"]
var distance = [2000, 10, 620]
var distanceCities = Dictionary(uniqueKeysWithValues: zip(cities, distance))

var groupCities = Dictionary(grouping: cities) { $0.first! }

var someDict:[Int: String] = [1: "One", 2: "Two", 3: "Three"]
var oldVal = someDict.updateValue("New One", forKey: 1)
var someVal = someDict[1]
someDict[1] = "Very new One"

var someDict:[Int: String] = [1: "One", 2: "Two", 3: "Three"]
someDict.removeValue(forKey: 1)
print(someDict)

var someDict:[Int: String] = [1: "One", 2: "Two", 3: "Three"]
someDict[1] = nil
print(someDict)

var someDict:[Int: String] = [1: "One", 2: "Two", 3: "Three"]
for (key, value) in someDict.enumerated() {
    print("\(key) \(value)")
}
var someDict:[Int: String] = [1: "One", 2: "Two", 3: "Three"]

let dictKeys = [Int](someDict.keys)
let dictValues = [String](someDict.values)

for (key) in dictKeys {
    print(key)
}

for (value) in dictValues {
    print(value)
}

var someDict1:[Int:String] = [1: "One", 2: "Two", 3: "Three"]
var someDict2:[Int:String] = [4: "Four", 5: "Five"]
var someDict3:[Int:String] = [Int:String]()

print("\(someDict1.isEmpty)")
print("\(someDict2.isEmpty)")
print("\(someDict3.isEmpty)")


var someDict1:[Int:String] = [1: "One", 2: "Two", 3: "Three"]
print(someDict1.count)

let cast = ["Vivien", "Marlon", "Kim", "Karl"]
let lowercaseNames = cast.map { $0.lowercased() }
print(lowercaseNames)

let letterCounts = cast.map { $0.count }
print(letterCounts)



let wizards = ["Harry", "Hermione", "Ron"]
let uppercased = wizards.map { $0.uppercased() }
print(uppercased)

let urls = urlString.compactMap { URL(String: $0)}


