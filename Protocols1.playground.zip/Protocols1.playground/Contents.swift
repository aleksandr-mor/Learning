import UIKit

var greeting = "Hello, playground"

class Person {
    var name: String
    
    init(name: String) {
        self.name = name
    }
}

protocol Doctor {
   // var name: String {get set}
    func doctorSkills()
}

//extension Doctor {
//    func doctorSkills() {
//            print("He's a doctor")
//        }
//}

protocol ProjectManager {
    func projectManagerSkills()
}
//extension ProjectManager {
//        func projectManagerSkills() {
//            print("He's a project manager")
//        }
//}

class Developer:Person , Doctor , ProjectManager {
   
    //var name: String
    
//    init(name: String) {
//        self.name = name
//    }
    
    
    func doctorSkills() {
        print("He's a doctor22")
    }

    func projectManagerSkills() {
        print("He's a project manager")
    }
    func developerSkills() {
        print("He's an iOS Developer")
    }

}
let aleks = Developer(name: "Aleks")
aleks.name = "vishal"
print(aleks.name)
aleks.doctorSkills()
aleks.developerSkills()
