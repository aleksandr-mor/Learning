import UIKit

struct Magic {
    var mage1: String
    var mage2: String
    var mage3: String

    func magical(){
    print("Boozinga!")
    }

}

var mages = Magic(mage1: "123", mage2: "234", mage3: "345")

print(mages.mage1)

struct Marks {
    var mark1: Int
    var mark2: Int
    var mark3: Int
    init(mark1: Int, mark2: Int, mark3: Int) {
        self.mark1 = mark1
        self.mark2 = mark2
        self.mark3 = mark3
    }
}

var marks = Marks(mark1: 30, mark2: 50, mark3: 60)
print(marks.mark1)

struct Players {
    var player1: String
    var player2: String
    var player3: String
}
var players = Players(player1: "A", player2: "B", player3: "C")
print(players.player1, players.player2, players.player3)
