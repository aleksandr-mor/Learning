import UIKit

final class Singleton {
    static let shared = Singleton()
    
    private init() {}
        
    
    func showMessage() {
        print("test")
    }
}

Singleton.shared.showMessage()
