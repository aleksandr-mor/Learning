import UIKit

class Person {
    
    var  name : String

    init(name : String) {
        self.name = name
    }
    
    func profession() {
        print("He has a profession")
    }
    
}

class Doctor : Person  {
    
    func doctorSkills() {
        print("He's a doctor!")
    }
    override func profession() {
        print("He's a doctor")
    }
}

class ProjectManager: Person {
    func managerSkills() {
        print("He's a manager!")
    }
    override func profession() {
        print("He's a manager")
    }
}

class Developer: Person  {
    func developerSkills() {
        print("He's a Developer!")
    }
}

let aleks =  Developer(name: "Aleks")//Person(name: "aleks")
print(aleks.name)
aleks.developerSkills()
aleks.profession()

