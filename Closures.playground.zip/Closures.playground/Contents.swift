import UIKit

//{
//    print("Hello World")
//}

//var greet = {
//    print("Hello, World!")
//}
//
//greet()

//let greetUser = { (name: String) in
//    print("Hey there, \(name).")
//}
//
//greetUser("Aleks")

//var findSquere = { (num: Int) -> (Int) in
//    var squere = num * num
//    return squere
//}
//
//var result = findSquere(3)
//
//print("Squere:", result)

//func grabLunch(search: () -> ()) {
//    print("Let's go out for lunch")
//
//    search()
//}
//
//grabLunch(search: {
//    print("Alfredo's Pizza: 2 miles away")
//})

