import UIKit

{
    print("Hello World")
}

var greet = {
    print("Hello, World!")
}

greet()

let greetUser = { (name: String) in
    print("Hey there, \(name).")
}

greetUser("Aleks")

var findSquere = { (num: Int) -> (Int) in
    var squere = num * num
    return squere
}

var result = findSquere(3)

print("Squere:", result)

func grabLunch(search: () -> ()) {
    print("Let's go out for lunch")

    search()
}

grabLunch(search: {
    print("Alfredo's Pizza: 2 miles away")
})

// Simple Closure
let test = {
    print("test")
}
test()

// Closure which accept parameter

let calSum = { (a : Int , b : Int) in

    print("sum is \(a+b)")

}
calSum(2, 3)

// Returning value from a closure

let someSum = { (x: Int, y: Int) -> String in
   return "\(x+y)"

}

print("sum is \(someSum(10, 11))")


let names = ["Chris", "Ales", "Ewa", "Barry", "Daniella"]

func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var reservedNames = names.sorted(by: backward)
