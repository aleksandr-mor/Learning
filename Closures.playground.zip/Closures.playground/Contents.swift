import UIKit

{
    print("Hello World")
}

var greet = {
    print("Hello, World!")
}

greet()

let greetUser = { (name: String) in
    print("Hey there, \(name).")
}

greetUser("Aleks")

var findSquere = { (num: Int) -> (Int) in
    var squere = num * num
    return squere
}

var result = findSquere(3)

print("Squere:", result)

func grabLunch(search: () -> ()) {
    print("Let's go out for lunch")

    search()
}

grabLunch(search: {
    print("Alfredo's Pizza: 2 miles away")
})

// Simple Closure
let test = {
    print("test")
}
test()

// Closure which accept parameter

let calSum = { (a : Int , b : Int) in

    print("sum is \(a+b)")

}
calSum(2, 3)

// Returning value from a closure

let someSum = { (x: Int, y: Int) -> String in
   return "\(x+y)"

}

print("sum is \(someSum(10, 11))")


// Closure as a parameter

let driving = {
    print("i am driving")
}

func travel(action: ()->Void) {
    print("I'm getting ready to go")
    action()
    print("I'm arraived")
}
travel(action: driving)


let names = ["Chris", "Ales", "Ewa", "Barry", "Daniella"]

func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var reservedNames = names.sorted(by: backward)

reservedNames = names.sorted(by: {(s1: String, s2: String) -> Bool in
    return s1 > s2
})

reversedNames = names.sorted(by: { s1, s2 in return s1 > s2})

reversedNames = names.sordted(by: {s1, s2 in s1 > s2})

reversedNames = names.sorted(by: {$0 > $1})

reversedNames = names.sorted(by: > )

// Trailing Closures

let string = numbers.map { (number) -> String in
    var number = number
    var output = ""
    repeat {
        output = digitNames [number % 10]! + output
        number /= 10
    } while number > 0
                return output
}
 strings is inferred to be of type [String]
 its value is ["OneSix", "FiveEight", "FiveOneZero"]


func doSomething(number: Int, onSuccess closure: (Int) -> Void) {
    closure(number * number * number)
}
doSomething(number: 100) { (numberCube) in
    print(numberCube)
}


// Capturing values

var i = 0

var closureArray = [()->()]()

for _ in 1...5 {

    closureArray.append {
        print(i)
    }

    i += 1
}

// here i will be 5

closureArray[0]()

closureArray[1]()

closureArray[2]()

closureArray[3]()

closureArray[4]()

