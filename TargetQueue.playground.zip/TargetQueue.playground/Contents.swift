import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

var value: Int = 2

let serialQueue = DispatchQueue(label: "serialQueue")
let concurrentQueue = DispatchQueue(label: "concurrentQueue", attributes: [.initiallyInactive, .concurrent])
concurrentQueue.setTarget(queue: serialQueue)
concurrentQueue.activate()

concurrentQueue.async {
    for j in 0...4 {
        value = j
        print("\(value) ✡️")
    }
}

extension DispatchQueue {
    static var currentLabel: String? {
        let name = __dispatch_queue_get_label(nil)
        return String(cString: name, encoding: .utf8)
    }
}

concurrentQueue.async {
    for j in 5...7 {
        value = j
        print("\(value) ✴️")
    }
}
