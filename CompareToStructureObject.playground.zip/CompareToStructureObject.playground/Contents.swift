import UIKit

struct House : Equatable {
    var street: String
}

var houseA = House(street: "street A, n. 10")
var houseB = House(street: "street A, n. 10")

houseA == houseB



class Person : Equatable {
    var name : String
    
    init(name : String) {
        self.name = name
    }
    
    static func == (lhs: Person, rhs: Person) -> Bool {
        return lhs.name == rhs.name
    }
}


let test1 = Person(name: "T")
let test2 = Person(name: "T")

test1 == test2

//  Reference https://www.hackingwithswift.com/example-code/language/how-to-conform-to-the-equatable-protocol

